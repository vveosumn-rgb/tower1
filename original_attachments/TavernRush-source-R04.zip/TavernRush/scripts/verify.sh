#!/usr/bin/env bash
# Сборка APK + unit-тесты + скриншоты. Использование: scripts/verify.sh <STAGE_ID>
set -o pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT" || exit 2
if [ -f /data/tools/env.sh ]; then source /data/tools/env.sh; fi
STAGE="${1:-manual}"
if [[ ! "$STAGE" =~ ^[A-Za-z0-9_-]+$ ]]; then echo "Некорректный STAGE_ID"; exit 2; fi
OUT="${TAVERNRUSH_OUT:-$(dirname "$ROOT")/pipeline}"
mkdir -p "$OUT/logs" "$OUT/apk" screenshots
rm -f screenshots/*.png
LOG="$OUT/logs/verify_${STAGE}.log"
DIRTY=$(git status --porcelain | wc -l)
HEAD=$(git rev-parse --short HEAD)
timeout 1500 ./gradlew assembleDebug testDebugUnitTest --console=plain > "$LOG" 2>&1
RC=$?
if [ "$(git rev-parse --short HEAD)" != "$HEAD" ]; then
  echo "HEAD изменился во время проверки" >> "$LOG"
  RC=3
fi
NOW=$(date -u +%FT%TZ)
if [ $RC -eq 0 ]; then
  N=$(ls screenshots/*.png 2>/dev/null | wc -l)
  EXPECTED=19
  [[ "$STAGE" == R02* ]] && EXPECTED=31
  [[ "$STAGE" == R03* || "$STAGE" == G* ]] && EXPECTED=60
  [[ "$STAGE" == R04* ]] && EXPECTED=95
  if [ "$N" -lt "$EXPECTED" ]; then
    echo "FAIL $STAGE $HEAD $NOW screenshots=$N expected>=$EXPECTED" > "$OUT/last_verify.txt"
    cat "$OUT/last_verify.txt"
    exit 4
  fi
  cp app/build/outputs/apk/debug/app-debug.apk "$OUT/apk/tavernrush-${STAGE}.apk"
  if [ "$N" -gt 0 ]; then
    magick montage screenshots/*.png -tile 6x -geometry 270x585+4+4 -background '#111111' "$OUT/logs/contact_${STAGE}.png" 2>/dev/null
  fi
  STATUS="OK"; [ "$DIRTY" -gt 0 ] && STATUS="OK_DIRTY"
  echo "$STATUS $STAGE $HEAD $NOW screenshots=$N uncommitted=$DIRTY" > "$OUT/last_verify.txt"
else
  echo "FAIL $STAGE $HEAD $NOW rc=$RC" > "$OUT/last_verify.txt"
  grep -E "^e: |error:|FAILED|What went wrong|Exception" -A6 "$LOG" | head -100
fi
grep -E "tests completed|BUILD (SUCCESSFUL|FAILED)" "$LOG" | tail -3
cat "$OUT/last_verify.txt"
[ "$RC" -eq 0 ] && [ "$DIRTY" -gt 0 ] && echo "ВНИМАНИЕ: есть незакоммиченные изменения — закоммитьте и перезапустите verify."
exit $RC

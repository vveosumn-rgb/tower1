package com.tavernrush.game.core

import com.tavernrush.game.content.Content
import com.tavernrush.game.content.Creatures
import com.tavernrush.game.meta.Meta
import com.tavernrush.game.meta.Profile
import com.tavernrush.game.meta.RunResult
import com.tavernrush.game.save.MemoryStore
import com.tavernrush.game.save.ProfileStore
import com.tavernrush.game.systems.CardSystem
import com.tavernrush.game.systems.Nemesis
import com.tavernrush.game.systems.World

/**
 * Машина состояний игры (чистый Kotlin): заставка → меню → забег ⇄ выбор карт / пауза → итоги → таверна.
 * Вызывается только из игрового потока (GameLoop) или из UI-потока, когда игровой поток остановлен.
 */
class Game(private val store: ProfileStore = MemoryStore()) {
    var screen = ScreenId.SPLASH
        private set
    /** Время на текущем экране, с (анимации UI). */
    var screenTime = 0f
        private set
    var prevScreen = ScreenId.SPLASH
        private set

    val profile: Profile = store.load()
    val world = World()
    val result = RunResult()
    /** Причина текущего выбора карт (CardSystem.LEVEL_UP/CHEST/TAVERN). */
    var cardReason = CardSystem.LEVEL_UP
        private set
    private var pauseReturn = ScreenId.RUN
    /** Фиксированный сид (тесты, скриншоты, будущий «ежедневный забег»). */
    var fixedSeed: Long? = null
    var selectedHero = Content.heroIndex(profile.extra["hero"] ?: "innkeeper").coerceAtLeast(0)
        private set
    /** Последнее купленное улучшение (подсветка в хабе) и его таймер. */
    var lastBought = -1
        private set
    var lastBoughtTime = 0f
        private set
    private val metaBuf = FloatArray(Content.statCount)

    /** Платформенные звук/вибрация. Game фильтрует по настройкам профиля. */
    var platform: GameEvents = GameEvents.None
    private val filtered = object : GameEvents {
        override fun sfx(id: Int) { if (profile.soundOn) platform.sfx(id) }
        override fun haptic(kind: Int) { if (profile.vibrationOn) platform.haptic(kind) }
        override fun exitRequested() { platform.exitRequested() }
    }
    val events: GameEvents get() = filtered

    init {
        if (profile.installSeed == 0L) profile.installSeed = Rng.mix(System.nanoTime() xor 0x5DEECE66DL)
        bankPending()
        world.events = filtered
        world.reset(1L, null)
    }

    /** Зачислить награду за прерванный (не завершённый) забег из прошлого сеанса. */
    private fun bankPending() {
        val g = profile.pendingRunGold
        if (g > 0) {
            Meta.credit(profile, g.toLong())
            profile.lastBankedGold = g
            profile.pendingRunGold = 0
            store.save(profile)
        }
    }

    fun go(s: ScreenId) {
        prevScreen = screen
        screen = s
        screenTime = 0f
    }

    fun tick(dt: Float) {
        if (!dt.isFinite() || dt <= 0f || dt > 0.25f) return
        screenTime += dt
        if (lastBoughtTime > 0f) lastBoughtTime -= dt
        when (screen) {
            ScreenId.SPLASH -> if (screenTime >= SPLASH_TIME) go(ScreenId.MENU)
            ScreenId.RUN -> tickRun(dt)
            else -> {}
        }
    }

    private fun tickRun(dt: Float) {
        val w = world
        w.tick(dt)
        w.encounter.takeJoin()?.let { f ->
            // Новый друг записывается сразу: если приложение убьют посреди забега, знакомство не пропадёт.
            f.metRun = profile.runCounter.coerceIn(0L, 10_000_000L).toInt()
            if (profile.befriend(f)) {
                result.newFriendId = f.id; result.newFriendName = f.name
                store.save(profile)
            }
        }
        when {
            w.player.dead -> if (w.deathTimer >= DEATH_DELAY) finishRun(false)
            w.victory -> if (w.victoryTimer >= VICTORY_DELAY) finishRun(true)
            w.pendingTavern > 0 -> { w.pendingTavern--; openCards(CardSystem.TAVERN) }
            w.pendingChests > 0 -> { w.pendingChests--; openCards(CardSystem.CHEST) }
            w.pendingLevelUps > 0 -> { w.pendingLevelUps--; openCards(CardSystem.LEVEL_UP) }
        }
    }

    private fun openCards(reason: Int) {
        cardReason = reason
        world.cards.roll(reason)
        world.moveX = 0f; world.moveY = 0f
        go(ScreenId.CARD_PICK)
    }

    fun startRun() {
        bankPending()
        profile.lastBankedGold = 0
        val seed = fixedSeed ?: Rng.mix(profile.installSeed + profile.runCounter * -0x61c8864680b583ebL)
        profile.runCounter++
        world.events = filtered
        world.reset(seed, Meta.bonuses(profile, metaBuf), selectedHero)
        world.setNemesis(profile.nemesisId, profile.nemesisRank, profile.nemesisWave, profile.nemesisSeed)
        world.rematchBoss = profile.rematchBoss
        world.fx.shakeScale = profile.shakePct / 100f
        world.team.setup(profile.friend(profile.teamLead), profile.friend(profile.teamReserve), profile.teamMode)
        var unmet = 0
        for (i in Content.creatures.indices) if (profile.friend(Content.creatures[i].id) == null) unmet = unmet or (1 shl i)
        world.encounter.arm(unmet, seed)
        result.valid = false
        result.newFriendId = ""; result.newFriendName = ""
        events.sfx(Sfx.CLICK)
        go(ScreenId.RUN)
    }

    fun pickCard(i: Int) {
        if (screen != ScreenId.CARD_PICK) return
        if (!world.cards.apply(i)) return
        events.sfx(Sfx.BUY)
        events.haptic(Haptic.TICK)
        go(ScreenId.RUN)
    }

    val inRun: Boolean get() = screen == ScreenId.RUN || screen == ScreenId.CARD_PICK || screen == ScreenId.PAUSE

    fun pause() {
        if (screen == ScreenId.RUN || screen == ScreenId.CARD_PICK) {
            pauseReturn = screen
            world.moveX = 0f; world.moveY = 0f
            go(ScreenId.PAUSE)
        }
    }

    fun resume() {
        if (screen == ScreenId.PAUSE) go(pauseReturn)
    }

    /** «Завершить забег» из паузы: засчитывается как поражение с наградой за прогресс. */
    fun abandonRun() {
        if (!inRun) return
        finishRun(false)
    }

    private fun finishRun(victory: Boolean) {
        Meta.computeReward(world, victory, profile, result)
        Meta.applyResult(profile, result)
        world.team.finish(profile)
        System.arraycopy(world.run.reactions, 0, result.reactions, 0, result.reactions.size)
        val before = profile.nemesisId
        Nemesis.onRunEnd(profile, world.run, victory, world.run.wave, world.seed)
        result.newNemesis = if (!victory && profile.nemesisId.isNotEmpty()) Nemesis.fullName(profile.nemesisId, profile.nemesisSeed, profile.nemesisRank) else ""
        result.killerLabel = killerLabel(victory)
        if (before.isNotEmpty() && profile.nemesisId.isEmpty()) result.nemesisSlain = true
        store.save(profile)
        events.sfx(if (victory) Sfx.VICTORY else Sfx.WAVE)
        go(ScreenId.RESULTS)
    }

    private fun killerLabel(victory: Boolean): String {
        if (victory) return ""
        val run = world.run
        if (run.killerEnemy < 0 || run.killerEnemy >= Content.enemies.size) return ""
        val def = Content.enemies[run.killerEnemy]
        return if (run.killerNamed) Nemesis.name(run.killerNameSeed, run.killerRank) + " · " + def.name else def.name
    }

    fun openHub() { events.sfx(Sfx.CLICK); go(ScreenId.HUB) }
    fun openMenu() { events.sfx(Sfx.CLICK); go(ScreenId.MENU) }
    fun openHeroes() { events.sfx(Sfx.CLICK); go(ScreenId.HEROES) }
    fun openSettings() { events.sfx(Sfx.CLICK); go(ScreenId.SETTINGS) }
    fun openTeam() { events.sfx(Sfx.CLICK); go(ScreenId.TEAM) }

    /** Правки команды допустимы только вне забега: ни режим, ни состав не меняются посреди боя. */
    fun setTeamMode(mode: Int): Boolean {
        if (inRun || mode !in 0 until Creatures.MODES) return false
        profile.teamMode = mode
        store.save(profile); events.sfx(Sfx.CLICK)
        return true
    }

    fun setTeamRole(id: String, role: Int): Boolean {
        if (inRun) return false
        val ok = when (role) {
            0 -> profile.setLead(id)
            1 -> if (id == profile.teamReserve) { profile.clearReserve(); true } else profile.setReserve(id)
            else -> false
        }
        if (ok) { store.save(profile); events.sfx(Sfx.CLICK) }
        return ok
    }

    fun chooseFriendSpec(id: String, spec: Int): Boolean {
        if (inRun || !profile.chooseSpec(id, spec)) return false
        store.save(profile); events.sfx(Sfx.BUY); events.haptic(Haptic.TICK)
        return true
    }
    /** Сохранить настройки (графика, управление): применяются GameApp на следующем кадре. */
    fun saveSettings() { store.save(profile) }
    fun selectHero(index: Int): Boolean {
        if (inRun || index !in Content.heroes.indices) return false
        selectedHero = index
        profile.extra["hero"] = Content.heroes[index].id
        store.save(profile)
        events.sfx(Sfx.CLICK)
        return true
    }

    fun buyUpgrade(i: Int): Boolean {
        if (i < 0 || i >= Content.hubUpgrades.size) return false
        if (!Meta.buy(profile, i)) {
            events.sfx(Sfx.HURT)
            return false
        }
        lastBought = i
        lastBoughtTime = 0.8f
        store.save(profile)
        events.sfx(Sfx.BUY)
        events.haptic(Haptic.TICK)
        return true
    }

    fun toggleSound() { profile.soundOn = !profile.soundOn; store.save(profile) }
    fun toggleVibration() { profile.vibrationOn = !profile.vibrationOn; store.save(profile); events.haptic(Haptic.TICK) }

    /** Системная кнопка «назад». */
    fun back() {
        when (screen) {
            ScreenId.MENU -> filtered.exitRequested()
            ScreenId.RUN, ScreenId.CARD_PICK -> pause()
            ScreenId.PAUSE -> resume()
            ScreenId.RESULTS -> openHub()
            ScreenId.HUB -> openMenu()
            ScreenId.HEROES -> openMenu()
            ScreenId.SETTINGS -> openMenu()
            ScreenId.TEAM -> openMenu()
            ScreenId.SPLASH -> go(ScreenId.MENU)
        }
    }

    /**
     * Приложение уходит в фон (вызывается, когда игровой поток уже остановлен): пауза
     * и страховочная запись награды «как если бы забег закончился сейчас» — прогресс не теряется
     * даже если система убьёт процесс. Завершение забега обнуляет страховку.
     */
    fun onHostPause() {
        pause()
        if (inRun && !world.player.dead && !world.victory) {
            Meta.computeReward(world, false, profile, tmpResult)
            profile.pendingRunGold = tmpResult.total
        }
        store.save(profile)
    }

    private val tmpResult = RunResult()

    companion object {
        const val SPLASH_TIME = 1.6f
        const val DEATH_DELAY = 1.6f
        const val VICTORY_DELAY = 3.2f
    }
}
